<div class="himbauan-2 mt-10 text-[12px] md:text-lg ">
    <div class="bg-stone-500 rounded-lg  flex flex-col items-center justify-center mx-6 relative w-auto py-5"
        data-aos="fade-up" data-aos-duration="1500">
        <p class="text-center text-white ">
            <strong>7 tamu undangan</strong> merespon akan Menghadiri Acara Pernikahan, Mari kirim konfirmasi
            kehadiran anda sekarang.
        </p>
        <button type="button" class="bg-yellow-600 p-2 w-auto text-white mt-2">Konfirmasi Kehadiran</button>
    </div>
</div>