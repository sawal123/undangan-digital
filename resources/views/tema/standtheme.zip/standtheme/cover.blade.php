<div class="cover h-full  w-full  mx-auto ">
          

    <div class="w-full h-[500px] relative flex bg-no-repeat bg-cover bg-center"
        style="background-image: url('{{ asset("storage/" . $data->thumbnailWas->thumbnail) }}');">

        <div class="top-0 h-10 w-full justify-center py-2  flex text-center items-center bg-white rounded-b-lg">
            {{-- <img src="assets/img/logo_akanikah.png" class="object-cover object-center h-8 my-2 " alt=""> --}}
        </div>

        <svg xmlns="http://www.w3.org/2000/svg" class="bottom-0 absolute " viewBox="0 0 1440 320">
            <path fill="#F7F4EF" fill-opacity="1"
                d="M0,192L480,256L960,128L1440,64L1440,320L960,320L480,320L0,320Z"></path>
        </svg>
    </div>

</div>